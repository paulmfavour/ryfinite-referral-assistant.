import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

const referralUrl = 'https://ryfinite.com/?ref=5mdnppqy';
const ryfiniteUrl = 'https://ryfinite.com/app';

void main() => runApp(const RyfiniteAssistantApp());

class RyfiniteAssistantApp extends StatelessWidget {
  const RyfiniteAssistantApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF7765F5);
    return MaterialApp(
      title: 'Ryfinite Referral Assistant',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF0B0D14),
        cardTheme: CardThemeData(
          color: const Color(0xFF171A26),
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
      ),
      home: const DashboardPage(),
    );
  }
}

class ReferralEntry {
  ReferralEntry({required this.label, required this.date, required this.status, this.notes = ''});
  final String label;
  final String date;
  final String status;
  final String notes;

  Map<String, dynamic> toJson() => {'label': label, 'date': date, 'status': status, 'notes': notes};
  factory ReferralEntry.fromJson(Map<String, dynamic> json) => ReferralEntry(
        label: json['label'] as String? ?? 'Referral',
        date: json['date'] as String? ?? '',
        status: json['status'] as String? ?? 'Pending',
        notes: json['notes'] as String? ?? '',
      );
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  static const _storageKey = 'ryfinite_referrals_v1';
  final List<ReferralEntry> _entries = [];
  String _gemsText = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw != null) {
      try {
        final decoded = jsonDecode(raw) as List<dynamic>;
        _entries.addAll(decoded.map((e) => ReferralEntry.fromJson(Map<String, dynamic>.from(e as Map))));
      } catch (_) {
        // Ignore damaged local data rather than blocking app launch.
      }
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, jsonEncode(_entries.map((e) => e.toJson()).toList()));
  }

  int get _confirmed => _entries.where((e) => e.status == 'Confirmed').length;
  int get _pending => _entries.where((e) => e.status == 'Pending').length;

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open the link.')));
    }
  }

  Future<void> _shareReferral() async {
    await Share.share('Join me on Ryfinite and explore its quests and rewards: $referralUrl');
  }

  Future<void> _addReferral() async {
    final labelController = TextEditingController();
    final notesController = TextEditingController();
    String status = 'Pending';
    final result = await showDialog<ReferralEntry>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Record a genuine referral'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: labelController, decoration: const InputDecoration(labelText: 'Label (optional)', hintText: 'e.g. Friend 1')),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: status,
                decoration: const InputDecoration(labelText: 'Status'),
                items: const [
                  DropdownMenuItem(value: 'Pending', child: Text('Pending')),
                  DropdownMenuItem(value: 'Confirmed', child: Text('Confirmed')),
                  DropdownMenuItem(value: 'Not eligible', child: Text('Not eligible')),
                ],
                onChanged: (value) => setDialogState(() => status = value ?? 'Pending'),
              ),
              const SizedBox(height: 12),
              TextField(controller: notesController, maxLines: 2, decoration: const InputDecoration(labelText: 'Notes (optional)')),
              const SizedBox(height: 8),
              Text('Only record people who genuinely registered through your link. Confirm status in Ryfinite before marking a reward as earned.', style: Theme.of(context).textTheme.bodySmall),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, ReferralEntry(
              label: labelController.text.trim().isEmpty ? 'Referral' : labelController.text.trim(),
              date: DateTime.now().toLocal().toString().split('.').first,
              status: status,
              notes: notesController.text.trim(),
            )), child: const Text('Save')),
          ],
        ),
      ),
    );
    labelController.dispose();
    notesController.dispose();
    if (result != null) {
      setState(() => _entries.insert(0, result));
      await _save();
    }
  }

  Future<void> _editEntry(int index) async {
    final current = _entries[index];
    String status = current.status;
    final result = await showDialog<String>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
        title: const Text('Update referral status'),
        content: DropdownButtonFormField<String>(
          value: status,
          items: const [
            DropdownMenuItem(value: 'Pending', child: Text('Pending')),
            DropdownMenuItem(value: 'Confirmed', child: Text('Confirmed')),
            DropdownMenuItem(value: 'Not eligible', child: Text('Not eligible')),
          ],
          onChanged: (value) => setDialogState(() => status = value ?? status),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(dialogContext, status), child: const Text('Update')),
        ],
      )),
    );
    if (result != null) {
      setState(() => _entries[index] = ReferralEntry(label: current.label, date: current.date, status: result, notes: current.notes));
      await _save();
    }
  }

  Future<void> _deleteEntry(int index) async {
    setState(() => _entries.removeAt(index));
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ryfinite Assistant', style: TextStyle(fontWeight: FontWeight.w700)),
        actions: [IconButton(tooltip: 'Open Ryfinite', onPressed: () => _openUrl(ryfiniteUrl), icon: const Icon(Icons.open_in_new))],
      ),
      floatingActionButton: FloatingActionButton.extended(onPressed: _addReferral, icon: const Icon(Icons.person_add_alt_1), label: const Text('Log referral')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 100), children: [
              Container(
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: const LinearGradient(colors: [Color(0xFF30245F), Color(0xFF171A2D)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Icon(Icons.auto_awesome, size: 28),
                  const SizedBox(height: 12),
                  Text('Grow through genuine invites', style: textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('Share your link, welcome real users, and track the status of your referrals.', style: textTheme.bodyMedium?.copyWith(color: Colors.white70)),
                  const SizedBox(height: 18),
                  SelectableText(referralUrl, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 16),
                  Wrap(spacing: 10, runSpacing: 10, children: [
                    FilledButton.icon(onPressed: _shareReferral, icon: const Icon(Icons.share), label: const Text('Share link')),
                    OutlinedButton.icon(onPressed: () => _openUrl(referralUrl), icon: const Icon(Icons.open_in_browser), label: const Text('Open referral page')),
                  ]),
                ]),
              ),
              const SizedBox(height: 16),
              Row(children: [
                Expanded(child: _StatCard(icon: Icons.people_alt_outlined, label: 'Logged', value: '${_entries.length}')),
                const SizedBox(width: 10),
                Expanded(child: _StatCard(icon: Icons.hourglass_top, label: 'Pending', value: '$_pending')),
                const SizedBox(width: 10),
                Expanded(child: _StatCard(icon: Icons.verified_outlined, label: 'Confirmed', value: '$_confirmed')),
              ]),
              const SizedBox(height: 16),
              Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [const Icon(Icons.diamond_outlined), const SizedBox(width: 8), Text('Gems / rewards note', style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold))]),
                const SizedBox(height: 8),
                Text('This starter version does not connect to Ryfinite reward data. Check your official Ryfinite account and record reward totals there; do not treat referral log counts as verified rewards.', style: textTheme.bodySmall),
                const SizedBox(height: 12),
                TextField(
                  decoration: const InputDecoration(labelText: 'Personal note (optional)', hintText: 'e.g. Gems shown in account: ...', border: OutlineInputBorder()),
                  onChanged: (value) => _gemsText = value,
                  onSubmitted: (value) async { final prefs = await SharedPreferences.getInstance(); await prefs.setString('ryfinite_gems_note', value); },
                ),
              ]))),
              const SizedBox(height: 20),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('Referral log', style: textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)), Text('${_entries.length} records', style: textTheme.bodySmall)]),
              const SizedBox(height: 8),
              if (_entries.isEmpty)
                Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(children: [const Icon(Icons.inbox_outlined, size: 36), const SizedBox(height: 8), const Text('No referrals logged yet'), const SizedBox(height: 4), Text('Use “Log referral” after a genuine person signs up.', style: textTheme.bodySmall, textAlign: TextAlign.center)])))
              else
                ..._entries.asMap().entries.map((item) {
                  final index = item.key;
                  final entry = item.value;
                  final color = entry.status == 'Confirmed' ? Colors.greenAccent : entry.status == 'Not eligible' ? Colors.redAccent : Colors.orangeAccent;
                  return Card(child: ListTile(
                    leading: CircleAvatar(backgroundColor: color.withValues(alpha: .15), child: Icon(Icons.person_outline, color: color)),
                    title: Text(entry.label),
                    subtitle: Text('${entry.date}\n${entry.status}${entry.notes.isEmpty ? '' : ' • ${entry.notes}'}'),
                    isThreeLine: true,
                    onTap: () => _editEntry(index),
                    trailing: PopupMenuButton<String>(onSelected: (value) { if (value == 'edit') _editEntry(index); if (value == 'delete') _deleteEntry(index); }, itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('Update status')), PopupMenuItem(value: 'delete', child: Text('Delete record'))]),
                  ));
                }),
              const SizedBox(height: 16),
              Card(child: Padding(padding: const EdgeInsets.all(14), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.info_outline), const SizedBox(width: 10), Expanded(child: Text('Independent helper app. Not affiliated with or endorsed by Ryfinite. No account creation bots, email harvesting, verification bypass, or self-referral automation.', style: textTheme.bodySmall))]))),
            ]),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({required this.icon, required this.label, required this.value});
  final IconData icon;
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 10), child: Column(children: [Icon(icon, size: 21), const SizedBox(height: 8), Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 2), Text(label, style: Theme.of(context).textTheme.labelSmall)])));
}
