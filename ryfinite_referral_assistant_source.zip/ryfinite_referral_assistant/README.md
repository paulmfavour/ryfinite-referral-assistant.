# Ryfinite Referral Assistant (Android / Flutter)

A private, manual-first Android helper for sharing the user's Ryfinite referral URL and tracking genuine referrals locally.

**Referral URL configured:** `https://ryfinite.com/?ref=5mdnppqy`

**Not affiliated with or endorsed by Ryfinite.** This project does not create email accounts, automate registrations, bypass verification, generate self-referrals, or claim to verify referral rewards.

## Included in this starter

- Referral link displayed, selectable, shareable, and opened in the external browser.
- Manual referral log with Pending / Confirmed / Not eligible status.
- Local persistence using `shared_preferences`.
- Manual reward notes; the app explicitly distinguishes user-entered data from verified platform rewards.
- An external link to the official Ryfinite app page.

## Features that require official Ryfinite support

The following are **not implemented** because no verified public Ryfinite API credentials or documentation were provided:

- Automatic list of referred accounts or referral status.
- Automatic Gems/reward balance retrieval.
- Webhooks for signup events or confirmed rewards.
- Authentication against Ryfinite from this third-party app.

Only add those features after Ryfinite publishes or directly provides an authorized API/partner integration and permits this use. Never put API secrets in the Android app; use a backend for authorized secrets.

## Build an APK

This bundle contains Flutter source files, not a compiled APK. A Flutter SDK/Android toolchain is needed to build it.

1. Install Flutter and Android Studio / Android SDK: https://docs.flutter.dev/get-started/install
2. In a terminal, go into this folder and run:

   ```sh
   flutter create . --platforms=android
   flutter pub get
   flutter analyze
   flutter build apk --release
   ```

3. The APK should be generated at `build/app/outputs/flutter-apk/app-release.apk`.
4. Copy the APK to your Android phone and install it. Android may ask you to allow installation from that file manager/browser. Only install APKs you trust.

If `flutter create .` asks to overwrite existing files, preserve this `lib/main.dart` and `pubspec.yaml`; generate only the missing Android scaffold.

## Local data

Referral log entries are stored on the device. They are not synced to the cloud, and deleting app data/uninstalling may remove them. Do not enter passwords, wallet seed phrases, private keys, or sensitive personal data into notes.

## Suggested advanced roadmap

1. Ask Ryfinite support whether an official referral API or partner integration exists and request the documentation/permission.
2. If approved, add a small backend (e.g. Firebase Cloud Functions) to call the authorized API securely.
3. Authenticate the owner and verify event signatures / API responses before displaying confirmed rewards.
4. Add export/backup and a privacy notice before storing any other users' personal information.
