# Official API integration checklist

Do not implement automatic reward tracking until each item is confirmed.

- [ ] Ryfinite confirms in writing that a third-party personal referral assistant is permitted.
- [ ] Official API documentation and base URL obtained directly from Ryfinite.
- [ ] API credentials granted for referral attribution and reward read-only access.
- [ ] Documented scopes, rate limits, webhook verification, and data retention requirements reviewed.
- [ ] API secrets stored server-side, never inside the APK.
- [ ] Only official, verified events update referral status or reward totals.
- [ ] Duplicate event handling and audit logging implemented.
- [ ] Privacy notice and user consent cover any personal data processed.
- [ ] No automation creates accounts, bypasses verification, or triggers referral actions on behalf of users.
